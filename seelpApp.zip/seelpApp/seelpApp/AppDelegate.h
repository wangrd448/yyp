//
//  AppDelegate.h
//  seelpApp
//
//  Created by 东哥 on 8/12/2022.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

