//
//  WindowController.h
//  seelpApp
//
//  Created by 东哥 on 15/2/2023.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface WindowController : NSWindowController

@end

NS_ASSUME_NONNULL_END
